<div class="w-100 m-0 p-5 fs-5 text-white row  text-center bg-dark" style="--bs-bg-opacity: .5">
    <span>Kelompok 1 RPL C</span>
    <span>Copyright @2023</span>
    <div class="d-flex justify-content-center gap-3 mt-3">
        <i class="fa-brands fa-lg fa-instagram"></i>
        <i class="fa-brands fa-lg fa-facebook"></i>
        <i class="fa-brands fa-lg fa-github"></i>
        <i class="fa-brands fa-lg fa-linkedin"></i>
        <i class="fa-brands fa-lg fa-youtube"></i>
    </div>
</div>