<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Penemu extends Model
{
    use HasFactory;
    protected $table = 'penemu'; // untuk menghubungkan ke tabel penemu
}
