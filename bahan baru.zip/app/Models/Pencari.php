<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pencari extends Model
{
    use HasFactory;
    protected $table = 'pencari'; // untuk menghubungkan ke tabel pencari
}
